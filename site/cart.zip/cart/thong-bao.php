<?php
require '../../global.php';
//-------------------------------//
$VIEW_NAME = "../cart/thong-bao-ui.php";
require '../layout.php';