<?php
require '../../global.php';
require '../../dao/hang-hoa.php';
//-------------------------------//
$VIEW_NAME = "../cart/cart.php";
require '../layout.php';